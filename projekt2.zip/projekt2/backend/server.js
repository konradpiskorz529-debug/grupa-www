const express = require('express');
const path = require('path');
const app = express();


// ===== BAZA DANYCH =====
const sequelize = require('./database');

// ===== MODELE =====
require('./models/Book');
require('./models/Movie');
require('./models/Rental');



// ===== ROUTES =====
const bookRoutes = require('./routes/bookRoutes')
const movieRoutes = require('./routes/movieRoutes');
const rentalRoutes = require('./routes/rentalRoutes');


// ===== MIDDLEWARE =====
app.use(express.json());

// ===== FRONTEND (STATYCZNE PLIKI) =====
app.use(express.static(path.join(__dirname, '../frontend')));

// ===== TEST BACKENDU =====
app.get('/test', (req, res) => {
  res.send('Backend działa ✅');
});

// ===== API =====
app.use('/api/books', bookRoutes);
app.use('/api/movies', movieRoutes);
app.use('/api/rentals', rentalRoutes);



// ===== START SERWERA =====
const PORT = 3000;

sequelize.sync().then(() => {
  app.listen(PORT, () => {
    console.log(`Serwer działa na http://localhost:${PORT}`);
  });
}).catch(err => {
  console.error('Błąd bazy:', err);
});
