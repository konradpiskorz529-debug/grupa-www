const Movie = require('../models/Movie');

// GET /api/movies
exports.getAllMovies = async (req, res) => {
  try {
    const movies = await Movie.findAll();
    res.json(movies);
  } catch (err) {
    res.status(500).json({ error: 'Błąd pobierania filmów' });
  }
};

// POST /api/movies
exports.createMovie = async (req, res) => {
  try {
    const { title, director, year } = req.body;

    if (!title || !director) {
      return res.status(400).json({ error: 'Tytuł i reżyser są wymagane' });
    }

    const movie = await Movie.create({ title, director, year });
    res.status(201).json(movie);
  } catch (err) {
    res.status(500).json({ error: 'Błąd dodawania filmu' });
  }
};

// PUT /api/movies/:id
exports.updateMovie = async (req, res) => {
  try {
    const movie = await Movie.findByPk(req.params.id);

    if (!movie) {
      return res.status(404).json({ error: 'Film nie istnieje' });
    }

    await movie.update(req.body);
    res.json(movie);
  } catch (err) {
    res.status(500).json({ error: 'Błąd edycji filmu' });
  }
};

// DELETE /api/movies/:id
exports.deleteMovie = async (req, res) => {
  try {
    const movie = await Movie.findByPk(req.params.id);

    if (!movie) {
      return res.status(404).json({ error: 'Film nie istnieje' });
    }

    await movie.destroy();
    res.json({ message: 'Film usunięty' });
  } catch (err) {
    res.status(500).json({ error: 'Błąd usuwania filmu' });
  }
};
