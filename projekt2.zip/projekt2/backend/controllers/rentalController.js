const Rental = require('../models/Rental');
const Book = require('../models/Book');
const Movie = require('../models/Movie');

// POST /api/rentals
exports.createRental = async (req, res) => {
  try {
    const { type, itemId } = req.body;

    if (!type || !itemId) {
      return res.status(400).json({ error: 'type i itemId są wymagane' });
    }

    if (type === 'book') {
      const book = await Book.findByPk(itemId);
      if (!book || !book.available) {
        return res.status(400).json({ error: 'Książka niedostępna' });
      }
      await book.update({ available: false });
    }

    if (type === 'movie') {
      const movie = await Movie.findByPk(itemId);
      if (!movie || !movie.available) {
        return res.status(400).json({ error: 'Film niedostępny' });
      }
      await movie.update({ available: false });
    }

    const rental = await Rental.create({ type, itemId });
    res.status(201).json(rental);

  } catch (err) {
    res.status(500).json({ error: 'Błąd wypożyczenia' });
  }
};

// GET /api/rentals
exports.getAllRentals = async (req, res) => {
  try {
    const rentals = await Rental.findAll();
    res.json(rentals);
  } catch (err) {
    res.status(500).json({ error: 'Błąd pobierania wypożyczeń' });
  }
};
