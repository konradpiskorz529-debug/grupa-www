const Book = require('../models/Book');

// GET /api/books
exports.getAllBooks = async (req, res) => {
  try {
    const books = await Book.findAll();
    res.json(books);
  } catch (error) {
    res.status(500).json({ error: 'Błąd pobierania książek' });
  }
};

// POST /api/books
exports.createBook = async (req, res) => {
  try {
    const { title, author, year } = req.body;

    if (!title || !author) {
      return res.status(400).json({ error: 'Tytuł i autor są wymagane' });
    }

    const book = await Book.create({ title, author, year });
    res.status(201).json(book);
  } catch (error) {
    res.status(500).json({ error: 'Błąd dodawania książki' });
  }
};

// PUT /api/books/:id
exports.updateBook = async (req, res) => {
  try {
    const { id } = req.params;
    const book = await Book.findByPk(id);

    if (!book) {
      return res.status(404).json({ error: 'Książka nie istnieje' });
    }

    await book.update(req.body);
    res.json(book);
  } catch (error) {
    res.status(500).json({ error: 'Błąd edycji książki' });
  }
};

// DELETE /api/books/:id
exports.deleteBook = async (req, res) => {
  try {
    const { id } = req.params;
    const book = await Book.findByPk(id);

    if (!book) {
      return res.status(404).json({ error: 'Książka nie istnieje' });
    }

    await book.destroy();
    res.json({ message: 'Książka usunięta' });
  } catch (error) {
    res.status(500).json({ error: 'Błąd usuwania książki' });
  }
};
