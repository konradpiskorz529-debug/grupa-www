const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const Rental = sequelize.define('Rental', {
  type: {
    type: DataTypes.STRING, // 'book' albo 'movie'
    allowNull: false,
  },
  itemId: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  rentDate: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
  returnDate: {
    type: DataTypes.DATE,
  },
});

module.exports = Rental;
